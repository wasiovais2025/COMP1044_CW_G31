<?php
// setup_admin.php
require 'db_connect.php';

$username = 'admin';
$password = 'admin123'; 
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$role = 'Admin';
$full_name = 'System Administrator';

$sql = "INSERT INTO users (username, password_hash, role, full_name) 
        VALUES ('$username', '$hashed_password', '$role', '$full_name')";

if ($conn->query($sql) === TRUE) {
    echo "Admin user created successfully! You can now log in with username: 'admin' and password: 'admin123'. Please delete this file now.";
} else {
    echo "Error: " . $conn->error;
}
?>