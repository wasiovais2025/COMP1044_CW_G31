<?php
// assessor_dashboard.php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'Assessor') {
    header("Location: login.php");
    exit();
}

$assessor_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$message = '';

// Handle Assessment Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_assessment'])) {
    $student_id = $conn->real_escape_string($_POST['student_id']);
    
    $tasks = (float)$_POST['tasks'];
    $health = (float)$_POST['health'];
    $knowledge = (float)$_POST['knowledge'];
    $presentation = (float)$_POST['presentation'];
    $clarity = (float)$_POST['clarity'];
    $lifelong = (float)$_POST['lifelong'];
    $project = (float)$_POST['project'];
    $time = (float)$_POST['time'];
    $comments = $conn->real_escape_string($_POST['comments']);

    // Exact weightages 
    $total_score = ($tasks * 0.10) + ($health * 0.10) + ($knowledge * 0.10) + 
                   ($presentation * 0.15) + ($clarity * 0.10) + ($lifelong * 0.15) + 
                   ($project * 0.15) + ($time * 0.15);

    $sql = "INSERT INTO assessments (student_id, tasks_marks, health_safety_marks, knowledge_marks, 
            presentation_marks, clarity_marks, lifelong_learning_marks, 
            project_management_marks, time_management_marks, total_score, comments) 
            VALUES ('$student_id', $tasks, $health, $knowledge, $presentation, 
            $clarity, $lifelong, $project, $time, $total_score, '$comments')";
    
    if ($conn->query($sql) === TRUE) {
        $message = "Assessment successful! Score: " . number_format($total_score, 2) . "%";
    } else {
        $message = "Error: " . $conn->error;
    }
}

$students_result = $conn->query("
    SELECT s.student_id, s.full_name, s.company_name, a.assessment_id 
    FROM students s 
    LEFT JOIN assessments a ON s.student_id = a.student_id
    WHERE s.assessor_id = $assessor_id
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assessor Dashboard | IRMS</title>
    <style>
        :root { --primary: #2e597d; --secondary: #e65100; --bg: #f8f9fa; --white: #ffffff; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; display: flex; }
        
        .sidebar { width: 250px; background: var(--primary); color: white; min-height: 100vh; padding: 20px; box-sizing: border-box; }
        .sidebar a { display: block; color: #e8f5e9; text-decoration: none; padding: 12px 0; transition: 0.3s; }
        .sidebar a:hover { color: #3cc3ba; }

        .main-content { flex-grow: 1; padding: 40px; }
        .card { background: var(--white); border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); padding: 25px; margin-bottom: 20px; }
        
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 15px; border-bottom: 2px solid #dee2e6; color: #495057; font-size: 0.8rem; text-transform: uppercase; }
        td { padding: 15px; border-bottom: 1px solid #edf2f7; }

        .btn { padding: 8px 16px; border-radius: 6px; border: none; cursor: pointer; font-weight: bold; transition: 0.3s; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-view { background: #e3f2fd; color: #1976d2; text-decoration: none; font-size: 0.8rem; padding: 5px 10px; border-radius: 4px; }
        
        .eval-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .input-group label { display: block; font-size: 0.8rem; margin-bottom: 5px; color: #666; }
        .input-group input { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        
        .status-badge { padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold; }
        .status-pending { background: #fff3e0; color: #e80940; }
        .status-complete { background: #e8f5e9; color: #2e597d; }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Assessor</h2>
        <p style="font-size: 0.8rem; opacity: 0.8;">Welcome, <br><strong><?php echo htmlspecialchars($full_name); ?></strong></p>
        <a href="assessor_dashboard.php">My Students</a>
        <a href="view_results.php">View Results</a>
        <a href="logout.php" style="margin-top: 50px; color: #e80940;">Logout</a>
    </div>

    <div class="main-content">
        <h1>Assessor Dashboard</h1>
        
        <?php if ($message): ?>
            <div style="background: #e8f5e9; color: #2e597d; padding: 15px; border-radius: 8px; margin-bottom: 20px;"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="card">
            <h3>Assigned Student Evaluations</h3>
            <table>
                <thead>
                    <tr>
                        <th>Student Details</th>
                        <th>Company</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($student = $students_result->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($student['full_name']); ?></strong><br>
                                <span style="font-size: 0.75rem; color: #666;"><?php echo htmlspecialchars($student['student_id']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($student['company_name']); ?></td>
                            <td>
                                <?php if ($student['assessment_id']): ?>
                                    <span class="status-badge status-complete">✓ Evaluated</span>
                                <?php else: ?>
                                    <span class="status-badge status-pending">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$student['assessment_id']): ?>
                                    <button class="btn btn-primary" onclick="document.getElementById('form-<?php echo $student['student_id']; ?>').style.display='block'">Evaluate</button>
                                <?php else: ?>
                                    <a href="view_results.php?search=<?php echo $student['student_id']; ?>" class="btn-view">View Marks</a>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr id="form-<?php echo $student['student_id']; ?>" style="display:none; background: #fafafa;">
                            <td colspan="4">
                                <form method="POST" style="padding: 20px;">
                                    <input type="hidden" name="submit_assessment" value="1">
                                    <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                                    
                                    <div class="eval-grid">
                                        <div class="input-group"><label>Tasks/Projects (10%)</label><input type="number" name="tasks" min="0" max="100" required></div>
                                        <div class="input-group"><label>Health & Safety (10%)</label><input type="number" name="health" min="0" max="100" required></div>
                                        <div class="input-group"><label>Theory Use (10%)</label><input type="number" name="knowledge" min="0" max="100" required></div>
                                        <div class="input-group"><label>Report Writing (15%)</label><input type="number" name="presentation" min="0" max="100" required></div>
                                        <div class="input-group"><label>Clarity (10%)</label><input type="number" name="clarity" min="0" max="100" required></div>
                                        <div class="input-group"><label>Learning (15%)</label><input type="number" name="lifelong" min="0" max="100" required></div>
                                        <div class="input-group"><label>Project Mgmt (15%)</label><input type="number" name="project" min="0" max="100" required></div>
                                        <div class="input-group"><label>Time Mgmt (15%)</label><input type="number" name="time" min="0" max="100" required></div>
                                    </div>

                                    <textarea name="comments" placeholder="Justification and feedback..." style="width:100%; height:80px; padding:10px; border-radius:4px; border:1px solid #ddd;" required></textarea>
                                    
                                    <div style="margin-top: 15px;">
                                        <button type="submit" class="btn btn-primary">Submit Grades</button>
                                        <button type="button" class="btn" style="background:#eee;" onclick="document.getElementById('form-<?php echo $student['student_id']; ?>').style.display='none'">Cancel</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>