<?php
// login.php
session_start();
require 'db_connect.php'; 

$error_message = '';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Added trim() to prevent invisible spacebar errors!
    $username = $conn->real_escape_string(trim($_POST['username']));
    $password = $_POST['password'];

    // Query to find the user
    $sql = "SELECT user_id, password_hash, role, full_name FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        
        // Verify the password 
        if (password_verify($password, $row['password_hash'])) {
            
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['full_name'] = $row['full_name'];
            $_SESSION['logged_in'] = true;

            // Redirect based on role
            if ($row['role'] == 'Admin') {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: assessor_dashboard.php");
            }
            exit();
        } else {
            $error_message = "Invalid password. Please try again.";
        }
    } else {
        $error_message = "No account found with that username.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Login | IRMS</title>
    <style>
        :root {
            --primary: #1a365d;
            --primary-light: #2b6cb0;
            --bg-color: #edf2f7;
            --text-main: #2d3748;
            --text-muted: #718096;
            --error-bg: #fff5f5;
            --error-text: #c53030;
            --error-border: #feb2b2;
        }

        body { 
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; 
            background-color: var(--bg-color);
            background-image: linear-gradient(135deg, #f6f8fa 0%, #edf2f7 100%);
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
            color: var(--text-main);
        }

        .login-wrapper {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            box-sizing: border-box;
        }

        .login-card { 
            background: #ffffff; 
            padding: 40px; 
            border-radius: 12px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.05), 0 4px 6px rgba(0,0,0,0.03); 
            border: 1px solid rgba(255,255,255,0.8);
        }

        .brand-header {
            text-align: center;
            margin-bottom: 35px;
        }

        .system-badge {
            display: inline-block;
            background: #ebf8ff;
            color: var(--primary-light);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 12px;
        }

        .brand-header h1 { 
            color: var(--primary); 
            font-size: 1.6rem; 
            margin: 0 0 8px 0; 
            letter-spacing: -0.5px;
        }
        
        .brand-header p {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin: 0;
        }

        .form-group { margin-bottom: 22px; }
        
        label { 
            display: block; 
            margin-bottom: 8px; 
            font-weight: 600; 
            font-size: 0.9rem;
            color: #4a5568;
        }

        input[type="text"], input[type="password"] { 
            width: 100%; 
            padding: 12px 16px; 
            border: 1px solid #cbd5e0; 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-size: 1rem;
            font-family: inherit;
            background-color: #f7fafc;
            transition: all 0.2s ease;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-light);
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(43, 108, 176, 0.1);
        }

        input::placeholder { color: #a0aec0; }

        button { 
            width: 100%; 
            padding: 14px; 
            background-color: var(--primary); 
            color: white; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-size: 1rem; 
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: background-color 0.2s, transform 0.1s;
            margin-top: 10px;
        }

        button:hover { background-color: var(--primary-light); }
        button:active { transform: translateY(1px); }

        .alert { 
            background-color: var(--error-bg); 
            color: var(--error-text);
            border: 1px solid var(--error-border);
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 0.9rem;
            text-align: center;
            margin-bottom: 25px;
            font-weight: 500;
        }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">
        <div class="brand-header">
            <span class="system-badge">Secure Access</span>
            <h1>Internship System</h1>
            <p>Please enter your credentials to continue</p>
        </div>
        
        <?php if ($error_message): ?>
            <div class="alert"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="e.g. admin" required autocomplete="username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="••••••••" required autocomplete="current-password">
            </div>
            <button type="submit">Sign In</button>
        </form>
    </div>
</div>

</body>
</html>