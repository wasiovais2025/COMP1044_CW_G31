<?php
session_start();
require 'db_connect.php';

if (!isset($_SESSION['logged_in'])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Query including required breakdown columns 
$sql = "SELECT s.student_id, s.full_name, s.programme, 
               a.tasks_marks, a.health_safety_marks, a.knowledge_marks, 
               a.presentation_marks, a.clarity_marks, a.lifelong_learning_marks, 
               a.project_management_marks, a.time_management_marks, 
               a.total_score, a.comments, u.full_name as assessor_name 
        FROM students s 
        JOIN assessments a ON s.student_id = a.student_id 
        JOIN users u ON s.assessor_id = u.user_id";

if ($role === 'Assessor') {
    $sql .= " WHERE s.assessor_id = $user_id";
    if ($search !== '') { $sql .= " AND s.student_id = '$search'"; }
} else {
    if ($search !== '') { $sql .= " WHERE s.student_id = '$search'"; }
}

$results = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Internship Results | IRMS</title>
    <style>
        :root {
            --primary: #2e597d;
            --secondary: #303f9f;
            --accent: #32d0d5;
            --bg: #f8f9fa;
            --text: #212529;
            --white: #ffffff;
        }

        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: var(--bg); 
            color: var(--text);
            margin: 0;
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: var(--primary);
            color: white;
            min-height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }

        .sidebar h2 { font-size: 1.2rem; border-bottom: 1px solid rgba(255,255,255,0.2); padding-bottom: 15px; }

        .sidebar a {
            display: block;
            color: #bdc3c7;
            text-decoration: none;
            padding: 12px 0;
            transition: color 0.3s;
        }

        .sidebar a:hover { color: var(--accent); }

        /* Main Content */
        .main-content { flex-grow: 1; padding: 40px; }

        .card {
            background: var(--white);
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            padding: 25px;
            overflow-x: auto;
        }

        .header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }

        table { width: 100%; border-collapse: collapse; margin-top: 10px; }

        th { 
            background: #f1f3f5; 
            color: #495057; 
            font-weight: 600; 
            text-transform: uppercase; 
            font-size: 0.75rem; 
            letter-spacing: 0.5px;
            padding: 15px 10px;
            border-bottom: 2px solid #dee2e6;
        }

        td { padding: 15px 10px; border-bottom: 1px solid #edf2f7; text-align: center; font-size: 0.9rem; }

        /* Highlight Weighted Columns [cite: 43] */
        .weightage { font-size: 0.7rem; color: #888; display: block; }

        .score-pill {
            background: #e7f5ff;
            color: #2e597d;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: bold;
        }

        .total-badge {
            background: var(--primary);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 1rem;
        }

        .comments-text { font-style: italic; color: #6c757d; text-align: left; max-width: 200px; }
        
        .search-bar {
            padding: 10px 15px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            width: 300px;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Results System</h2>
        <p style="font-size: 0.8rem; opacity: 0.7;">Logged in as: <br><strong><?php echo $full_name; ?></strong></p>
        <a href="<?php echo ($role === 'Admin' ? 'admin_dashboard.php' : 'assessor_dashboard.php'); ?>">Dashboard</a>
        <a href="view_results.php">View All Results</a>
        <a href="logout.php" style="margin-top: 50px; color: #e80940;">Sign Out</a>
    </div>

    <div class="main-content">
        <div class="header-flex">
            <h1 style="margin: 0;">Internship Performance</h1>
            <form method="GET">
                <input type="text" name="search" class="search-bar" placeholder="Search Student ID..." value="<?php echo htmlspecialchars($search); ?>">
            </form>
        </div>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Tasks <span class="weightage">10%</span></th>
                        <th>Safety <span class="weightage">10%</span></th>
                        <th>Theory <span class="weightage">10%</span></th>
                        <th>Report <span class="weightage">15%</span></th>
                        <th>Clarity <span class="weightage">10%</span></th>
                        <th>Learning <span class="weightage">15%</span></th>
                        <th>Project <span class="weightage">15%</span></th>
                        <th>Time <span class="weightage">15%</span></th>
                        <th>Final Mark</th>
                        <th>Feedback</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $results->fetch_assoc()): ?>
                        <tr>
                            <td style="text-align: left;">
                                <strong><?php echo htmlspecialchars($row['full_name']); ?></strong><br>
                                <span style="font-size: 0.75rem; color: #6c757d;"><?php echo htmlspecialchars($row['student_id']); ?></span>
                            </td>
                            <td><span class="score-pill"><?php echo $row['tasks_marks']; ?></span></td>
                            <td><span class="score-pill"><?php echo $row['health_safety_marks']; ?></span></td>
                            <td><span class="score-pill"><?php echo $row['knowledge_marks']; ?></span></td>
                            <td><span class="score-pill"><?php echo $row['presentation_marks']; ?></span></td>
                            <td><span class="score-pill"><?php echo $row['clarity_marks']; ?></span></td>
                            <td><span class="score-pill"><?php echo $row['lifelong_learning_marks']; ?></span></td>
                            <td><span class="score-pill"><?php echo $row['project_management_marks']; ?></span></td>
                            <td><span class="score-pill"><?php echo $row['time_management_marks']; ?></span></td>
                            <td><span class="total-badge"><?php echo number_format($row['total_score'], 2); ?>%</span></td>
                            <td class="comments-text"><?php echo htmlspecialchars($row['comments']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>