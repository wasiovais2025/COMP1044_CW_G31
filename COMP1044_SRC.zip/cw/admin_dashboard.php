<?php
// admin_dashboard.php
session_start();
require 'db_connect.php';

// Ensure user is logged in and is an Admin
if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

$message = '';

// Handle Form Submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // ADD NEW ASSESSOR 
    if (isset($_POST['add_assessor'])) {
        $username = $conn->real_escape_string($_POST['assessor_username']);
        $password = password_hash($_POST['assessor_password'], PASSWORD_DEFAULT);
        $full_name = $conn->real_escape_string($_POST['assessor_fullname']);
        
        $sql = "INSERT INTO users (username, password_hash, role, full_name) VALUES ('$username', '$password', 'Assessor', '$full_name')";
        if ($conn->query($sql) === TRUE) {
            $message = "Assessor account created successfully.";
        } else {
            $message = "Error creating assessor: " . $conn->error;
        }
    }

    // ADD NEW STUDENT 
    if (isset($_POST['add_student'])) {
        $student_id = $conn->real_escape_string($_POST['student_id']);
        $full_name = $conn->real_escape_string($_POST['student_fullname']);
        $programme = $conn->real_escape_string($_POST['programme']);
        $company_name = $conn->real_escape_string($_POST['company_name']);
        $assessor_id = (int)$_POST['assessor_id'];

        $sql = "INSERT INTO students (student_id, full_name, programme, company_name, assessor_id) 
                VALUES ('$student_id', '$full_name', '$programme', '$company_name', $assessor_id)";
        if ($conn->query($sql) === TRUE) {
            $message = "Student added and assigned successfully.";
        } else {
            $message = "Error adding student: " . $conn->error;
        }
    }
}

// Fetch Assessors for the dropdown
$assessors_result = $conn->query("SELECT user_id, full_name FROM users WHERE role = 'Assessor'");

// Fetch Students for the display table
$students_result = $conn->query("
    SELECT s.student_id, s.full_name, s.programme, s.company_name, u.full_name as assessor_name 
    FROM students s 
    LEFT JOIN users u ON s.assessor_id = u.user_id
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Internship Management</title>
    <style>
        :root {
            --primary: #1a365d;
            --primary-light: #2b6cb0;
            --accent: #e53e3e;
            --success: #38a169;
            --bg: #edf2f7;
            --card-bg: #ffffff;
            --text-main: #2d3748;
            --text-muted: #718096;
            --border: #e2e8f0;
        }

        body { 
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; 
            background-color: var(--bg); 
            color: var(--text-main);
            margin: 0;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 15px rgba(0,0,0,0.05);
            z-index: 10;
        }

        .sidebar-header {
            border-bottom: 1px solid rgba(255,255,255,0.1);
            padding-bottom: 20px;
            margin-bottom: 25px;
        }

        .sidebar-header h2 { margin: 0; font-size: 1.5rem; letter-spacing: 0.5px; }
        .sidebar-header p { margin: 5px 0 0; font-size: 0.85rem; color: #a0aec0; }

        .nav-link {
            color: #cbd5e0;
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 8px;
            font-weight: 500;
            transition: all 0.2s;
            display: block;
        }

        .nav-link:hover, .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        .logout-btn { margin-top: auto; color: #fc8181; }
        .logout-btn:hover { background: rgba(229, 62, 62, 0.1); color: #feb2b2; }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 40px;
            overflow-y: auto;
        }

        .page-title { margin-top: 0; color: var(--primary); font-size: 2rem; margin-bottom: 30px; }

        .message {
            background: #c6f6d5;
            color: #22543d;
            padding: 15px 20px;
            border-left: 4px solid var(--success);
            border-radius: 6px;
            margin-bottom: 30px;
            font-weight: 500;
            box-shadow: 0 2px 5px rgba(0,0,0,0.02);
        }

        /* Grid for Forms */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.02), 0 1px 3px rgba(0,0,0,0.05);
            border: 1px solid var(--border);
        }

        .card h3 {
            margin-top: 0;
            color: var(--primary);
            border-bottom: 2px solid var(--bg);
            padding-bottom: 12px;
            margin-bottom: 20px;
            font-size: 1.25rem;
        }

        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 0.9rem; color: #4a5568; }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #cbd5e0;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 0.95rem;
            transition: border-color 0.2s;
            background: #fff;
        }
        
        .form-control:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 3px rgba(43, 108, 176, 0.1); }

        .btn {
            background: var(--primary-light);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            font-size: 1rem;
            transition: background 0.2s;
            margin-top: 10px;
        }
        .btn:hover { background: var(--primary); }

        /* Tables */
        .table-container { overflow-x: auto; margin-top: 10px; }
        table { width: 100%; border-collapse: collapse; white-space: nowrap; }
        
        th {
            background: #f7fafc;
            color: var(--text-muted);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 15px;
            text-align: left;
            border-bottom: 2px solid var(--border);
        }
        
        td { padding: 15px; border-bottom: 1px solid var(--border); font-size: 0.95rem; }
        tr:hover td { background-color: #fbfcfd; }

        .score-pill {
            background: #edf2f7;
            color: var(--primary);
            padding: 4px 10px;
            border-radius: 20px;
            font-family: monospace;
            font-weight: bold;
            font-size: 0.9rem;
        }

        .final-grade {
            background: var(--primary-light);
            color: white;
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: bold;
        }

        .badge-unassigned { background: #feebc8; color: #c05621; padding: 4px 10px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
        
        th small { display: block; color: var(--primary-light); font-weight: bold; margin-top: 4px; font-size: 0.7rem; }
        
        .feedback-cell { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--text-muted); font-style: italic; }
    </style>
</head>
<body>

    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>IRMS Admin</h2>
            <p>Logged in as: <br><strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong></p>
        </div>
        <nav>
            <a href="#manage" class="nav-link active">Manage Records</a>
            <a href="#students" class="nav-link">Directory</a>
            <a href="#results" class="nav-link">Results Overview</a>
            <a href="logout.php" class="nav-link logout-btn">Sign Out</a>
        </nav>
    </aside>

    <main class="main-content">
        <h1 class="page-title">System Administration</h1>

        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="form-grid" id="manage">
            <div class="card">
                <h3>Create Assessor Account</h3>
                <form method="POST" action="admin_dashboard.php">
                    <input type="hidden" name="add_assessor" value="1">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="assessor_fullname" class="form-control" placeholder="e.g. Dr. Jane Doe" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="assessor_username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="assessor_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn">Add Assessor</button>
                </form>
            </div>

            <div class="card">
                <h3>Add Student & Assign Internship</h3>
                <form method="POST" action="admin_dashboard.php">
                    <input type="hidden" name="add_student" value="1">
                    <div style="display: flex; gap: 15px;">
                        <div class="form-group" style="flex: 1;">
                            <label>Student ID</label>
                            <input type="text" name="student_id" class="form-control" required>
                        </div>
                        <div class="form-group" style="flex: 2;">
                            <label>Full Name</label>
                            <input type="text" name="student_fullname" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Programme</label>
                        <input type="text" name="programme" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Company Name</label>
                        <input type="text" name="company_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Assign Assessor</label>
                        <select name="assessor_id" class="form-control" required>
                            <option value="">-- Select Assessor --</option>
                            <?php 
                            $assessors_result->data_seek(0);
                            while($row = $assessors_result->fetch_assoc()): 
                            ?>
                                <option value="<?php echo $row['user_id']; ?>">
                                    <?php echo htmlspecialchars($row['full_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn">Register Student</button>
                </form>
            </div>
        </div>

        <div class="card" id="students" style="margin-bottom: 40px;">
            <h3>Internship Directory</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Programme</th>
                            <th>Company</th>
                            <th>Assigned Assessor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($students_result->num_rows > 0): ?>
                            <?php while($student = $students_result->fetch_assoc()): ?>
                                <tr>
                                    <td style="font-family: monospace; font-weight: bold; color: var(--primary);"><?php echo htmlspecialchars($student['student_id']); ?></td>
                                    <td><strong><?php echo htmlspecialchars($student['full_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($student['programme']); ?></td>
                                    <td><?php echo htmlspecialchars($student['company_name']); ?></td>
                                    <td>
                                        <?php if($student['assessor_name']): ?>
                                            <?php echo htmlspecialchars($student['assessor_name']); ?>
                                        <?php else: ?>
                                            <span class="badge-unassigned">Pending Assignment</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 30px; color: var(--text-muted);">No students found in the database.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card" id="results">
            <h3>Comprehensive Internship Results</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: -10px; margin-bottom: 20px;">
                Full breakdown of all weighted criteria and qualitative feedback from assessors.
            </p>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Name</th>
                            <th style="text-align: center;">Tasks<small>10%</small></th>
                            <th style="text-align: center;">Safety<small>10%</small></th>
                            <th style="text-align: center;">Theory<small>10%</small></th>
                            <th style="text-align: center;">Report<small>15%</small></th>
                            <th style="text-align: center;">Clarity<small>10%</small></th>
                            <th style="text-align: center;">Learning<small>15%</small></th>
                            <th style="text-align: center;">Project<small>15%</small></th>
                            <th style="text-align: center;">Time<small>15%</small></th>
                            <th style="text-align: center;">Final Grade</th>
                            <th>Assessor Comments</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Fetch all assessment data joining students and assessments tables
                        $all_results = $conn->query("
                            SELECT s.student_id, s.full_name, 
                                   a.tasks_marks, a.health_safety_marks, a.knowledge_marks, 
                                   a.presentation_marks, a.clarity_marks, a.lifelong_learning_marks, 
                                   a.project_management_marks, a.time_management_marks, 
                                   a.total_score, a.comments 
                            FROM students s 
                            JOIN assessments a ON s.student_id = a.student_id
                        ");

                        if ($all_results->num_rows > 0): 
                            while($res = $all_results->fetch_assoc()): 
                        ?>
                            <tr>
                                <td style="font-family: monospace; font-weight: bold;"><?php echo htmlspecialchars($res['student_id']); ?></td>
                                <td><strong><?php echo htmlspecialchars($res['full_name']); ?></strong></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['tasks_marks']; ?></span></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['health_safety_marks']; ?></span></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['knowledge_marks']; ?></span></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['presentation_marks']; ?></span></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['clarity_marks']; ?></span></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['lifelong_learning_marks']; ?></span></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['project_management_marks']; ?></span></td>
                                <td style="text-align: center;"><span class="score-pill"><?php echo $res['time_management_marks']; ?></span></td>
                                <td style="text-align: center;">
                                    <span class="final-grade"><?php echo number_format($res['total_score'], 2); ?>%</span>
                                </td>
                                <td class="feedback-cell" title="<?php echo htmlspecialchars($res['comments']); ?>">
                                    <?php echo htmlspecialchars($res['comments']); ?>
                                </td>
                            </tr>
                        <?php 
                            endwhile; 
                        else: 
                        ?>
                            <tr>
                                <td colspan="12" style="text-align: center; color: var(--text-muted); padding: 30px;">
                                    No internship evaluations have been submitted yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>